﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.Configuration;
using System.IO.Ports;

namespace RemoteLibrary
{
    public class Emails
    {
        public static bool SendTicketResolveEmail(string To, string Subject, string Customer, string Description,string comment)
        {
            try
            {
                MailMessage msg = new MailMessage();
                string _from = ConfigurationManager.AppSettings["fromEmailId"].ToString();
                msg.From = new MailAddress(_from);
                msg.To.Add(To.Trim(new char[] { ',' }));
                msg.IsBodyHtml = true;
                msg.Subject = Subject;
                int portNumber = Convert.ToInt32(ConfigurationManager.AppSettings["smtpPort"]);
                string smtpClient = Convert.ToString(ConfigurationManager.AppSettings["smtpClient"]);
                string fromPwd = ConfigurationManager.AppSettings["fromPassword"].ToString();
                var client = new SmtpClient(smtpClient, portNumber)
                {
                    Credentials = new NetworkCredential(_from, fromPwd),
                    EnableSsl = true
                };
                StringBuilder sbBody = new StringBuilder();

                sbBody.Append("<div style='margin: 0px'>");
                sbBody.Append("<div style='width: 700px; margin-left: auto; margin-right: auto'>");
                sbBody.Append("<table border='0' cellpadding='0' cellspacing='0' width='100%'>");
                sbBody.Append("<tbody >");

                sbBody.Append("<span style='font: bold 17px Arial; color: rgb(105,105,105)'>Hi " + Customer + "!</span><br><br>");
                sbBody.Append("<span style='font: 13px/18px Arial; color: rgb(115,122,128)'>Your ticket has been resolved.!<br>Please find the ticket description and the comment provided for your ticket.</span><br><br>");
                sbBody.Append("<table style='font: 12px Arial; color: rgb(102,102,102)' border='0' cellpadding='0' cellspacing='0' width='100%'>");


                sbBody.Append(" <tr><td colspan='2'></td></tr>");
                sbBody.Append("<tr><td colspan='2' style='background-color: rgb(9,145,172); padding-left: 15px; font: 12px Arial; color: rgb(255,255,255)' height='25px'>Description</td></tr>");
                sbBody.Append("<tr><td colspan='2'></td></tr>");
                sbBody.Append("<tr><td colspan='2' style='padding-left: 15px'><p style='line-height:25px;'>" + Description + "</p></td></tr>");

                sbBody.Append(" <tr><td colspan='2'></br></br></br></br></td></tr>");
                sbBody.Append("<tr><td colspan='2' style='background-color: rgb(9,145,172); padding-left: 15px; font: 12px Arial; color: rgb(255,255,255)' height='25px'>Admin Comment</td></tr>");
                sbBody.Append("<tr><td colspan='2'></td></tr>");
                sbBody.Append("<tr><td colspan='2' style='padding-left: 15px'><p style='line-height:25px;'>" + comment + "</p></td></tr>");

                sbBody.Append(" <tr><td colspan='2'></td></tr>");
                sbBody.Append(" </tbody></table><br>");
                sbBody.Append(" </tbody></table></div>");

                var view = AlternateView.CreateAlternateViewFromString(sbBody.ToString(), null, "text/html");

                msg.AlternateViews.Add(view);

                try
                {
                    client.Send(msg);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return true;
        }

        public static bool SendEmailToEmployee(string To, string Name)
        {
            //try
            //{
                MailMessage msg = new MailMessage();
                string _from = ConfigurationManager.AppSettings["fromEmailId"].ToString();
                msg.From = new MailAddress(_from);
                msg.To.Add(To.Trim(new char[] { ',' }));
                msg.IsBodyHtml = true;
                msg.Subject = "Warning email from Admin!";
                int portNumber = Convert.ToInt32(ConfigurationManager.AppSettings["smtpPort"]);
                string smtpClient = Convert.ToString(ConfigurationManager.AppSettings["smtpClient"]);
                string fromPwd = ConfigurationManager.AppSettings["fromPassword"].ToString();
                var client = new SmtpClient(smtpClient, portNumber)
                {
                    Credentials = new NetworkCredential(_from, fromPwd),
                    EnableSsl = true
                };
                StringBuilder sbBody = new StringBuilder();

                sbBody.Append("<div style='margin: 0px'>");
                sbBody.Append("<div style='width: 700px; margin-left: auto; margin-right: auto'>");
                sbBody.Append("<table border='0' cellpadding='0' cellspacing='0' width='100%'>");
                sbBody.Append("<tbody >");

                sbBody.Append("<span style='font: bold 17px Arial; color: rgb(105,105,105)'>Hi " + Name + "!</span><br><br>");
                sbBody.Append("<span style='font: 13px/18px Arial; color: rgb(115,122,128)'></span><br><br>");
                sbBody.Append("<table style='font: 12px Arial; color: rgb(102,102,102)' border='0' cellpadding='0' cellspacing='0' width='100%'>");


                string body = "Your performance is not upto the mark! Please improve your performance or fired from job!<br><br><br>Admin";
                sbBody.Append("<tr><td colspan='2'></td></tr>");
                sbBody.Append("<tr><td colspan='2' style='padding-left: 15px'><p style='line-height:25px;'>" + body + "</p></td></tr>");

                
                sbBody.Append(" <tr><td colspan='2'></td></tr>");
                sbBody.Append(" </tbody></table><br>");
                sbBody.Append(" </tbody></table></div>");

                var view = AlternateView.CreateAlternateViewFromString(sbBody.ToString(), null, "text/html");

                msg.AlternateViews.Add(view);

                try
                {
                    client.Send(msg);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            //}
            //catch (Exception e)
            //{
              
            //}
            return true;
        }

        public static void SendSMS(string MobileNumber, string Message)
        {
            try
            {
                string portname = Convert.ToString(ConfigurationManager.AppSettings["SMSPort"]);
                SerialPort port = new SerialPort(portname, 9600);
                port.Open();
                port.Write("at\r\n");
                port.Write("at+cmgf=1\r\n");
                port.Write("at+cmgs=\"" + MobileNumber + "\"\r\n");
                port.Write(Message);
                port.Write(Convert.ToString(Convert.ToChar(26)));
                port.Write("at\r\n");
                port.Write("at\r\n");
                port.Close();
            }
            catch { }
        }
    }
}
