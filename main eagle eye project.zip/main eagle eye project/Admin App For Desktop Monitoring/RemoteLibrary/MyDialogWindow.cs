﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace RemoteLibrary
{
    public partial class MyDialogWindow : Form
    {
        Thread th = null;
        public MyDialogWindow(string data)
        {
            InitializeComponent();
            Label.CheckForIllegalCrossThreadCalls = false;
            lblMessage.Text = data;
            th = new Thread(new ThreadStart(CloseIt));
            th.Start();
        }

        private void CloseIt()
        {
            try
            {
                Thread.Sleep(5000);
                this.Close();
            }
            catch (Exception e)
            {
                this.Close();
            }
        }
    }
}
