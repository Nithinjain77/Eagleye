﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;
namespace RemoteLibrary
{
    public class RemoteClass : MarshalByRefObject
    {

        public byte[] CaptureScreen()
        {
            Bitmap _desktopBMP = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format24bppRgb);
            using (Graphics _graphicObj = Graphics.FromImage(_desktopBMP))
            {
                _graphicObj.CopyFromScreen(0, 0, 0, 0, Screen.PrimaryScreen.Bounds.Size, CopyPixelOperation.SourceCopy);
                _graphicObj.Dispose();
            }
            MemoryStream _streamObj = new MemoryStream();
            _desktopBMP.Save(_streamObj, ImageFormat.Png);
            return _streamObj.ToArray();
        }

        public static string GetMyIpAddress()
        {
            IPAddress[] ips = Dns.GetHostEntry(System.Environment.MachineName).AddressList;
            foreach (IPAddress ip in ips)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                    return ip.ToString();
            }
            return "127.0.0.1";
        }

        public string UpTime()
        {
                using (var uptime = new PerformanceCounter("System", "System Up Time"))
                {
                    uptime.NextValue();       //Call this an extra time before reading its value
                    TimeSpan span = TimeSpan.FromSeconds(uptime.NextValue());
                    return span.Hours +":" + span.Minutes + ":" + span.Seconds;
                }
        }

        public string[] GetProcesses()
        {
            Process [ ] p = Process.GetProcesses();
            string[] names = new string[p.Length];
            for (int i = 0; i < p.Length; i++)
                names[i] = p[i].Id + "~"+ p[i].ProcessName;

            return names;
        }

        public void KillProcess(int ProcessId)
        {
            Process.GetProcessById(ProcessId).Kill();
        }

        public string[] GetMemory()
        {
            string[] drives = Directory.GetLogicalDrives();

            string[] items = new String[drives.Length];

            int i = 0;
            foreach (string drive in drives)
            {
                if (Directory.Exists(drive))
                {
                    string driv = drive.Remove(drive.Length - 1, 1);

                    string s = string.Format("win32_logicaldisk.deviceid=\"{0}\"", driv);
                    ManagementObject disk = new ManagementObject(s);
                    disk.Get();
                    items[i++] = drive + "$" + disk["Size"] + "$" + disk["FreeSpace"];
                }
            }
            return items;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        internal const int SE_PRIVILEGE_ENABLED = 0x00000002;
        internal const int TOKEN_QUERY = 0x00000008;
        internal const int TOKEN_ADJUST_PRIVILEGES = 0x00000020;
        internal const string SE_SHUTDOWN_NAME = "SeShutdownPrivilege";
        internal const int EWX_LOGOFF = 0x00000000;
        internal const int EWX_SHUTDOWN = 0x00000001;
        internal const int EWX_REBOOT = 0x00000002;
        internal const int EWX_FORCE = 0x00000004;
        internal const int EWX_POWEROFF = 0x00000008;
        internal const int EWX_FORCEIFHUNG = 0x00000010;
        public void shutdown()
        {
            Process.Start("shutdown", "/s /t 0");
        }
        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);

        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall,
            ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);

        [DllImport("user32.dll")]
        public static extern void keybd_event(byte bvk, byte bscan, long dw, long dc);

        [DllImport("user32.dll")]
        public static extern bool ExitWindowsEx(uint uflags, int reason);

        public void ShutDownSystem()
        {
            Process pro = Process.GetCurrentProcess();
            bool ok;
            TokPriv1Luid tp;
            IntPtr hproc = pro.Handle;
            IntPtr htok = IntPtr.Zero;
            ok = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_ENABLED;
            ok = LookupPrivilegeValue(null, SE_SHUTDOWN_NAME, ref tp.Luid);
            ok = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            ExitWindowsEx(1, 0);
        }

        internal struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        [DllImport("User32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [DllImport("Kernel32.dll")]
        private static extern uint GetLastError();

        public uint GetIdleTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            GetLastInputInfo(ref lastInPut);

            return ((uint)Environment.TickCount - lastInPut.dwTime);
        }
        /// <summary>
        /// Get the Last input time in milliseconds
        /// </summary>
        /// <returns></returns>
        public long GetLastInputTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            if (!GetLastInputInfo(ref lastInPut))
            {
                throw new Exception(GetLastError().ToString());
            }
            return lastInPut.dwTime;
        }


        public void SendAlert(string msg)
        {
            MyDialogWindow dialog = new MyDialogWindow(msg);
            dialog.ShowDialog();
            //MessageBox.Show(msg, "Admin", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

         
    }
}
