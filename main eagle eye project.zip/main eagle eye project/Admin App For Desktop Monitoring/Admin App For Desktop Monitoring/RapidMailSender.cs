﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace Admin_App_For_Desktop_Monitoring
{
    class RapidMailSender
    {
        public static void Send(string Id, string Body)
        {
            try
            {
                SmtpClient smtp = new SmtpClient();
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com";
                smtp.Credentials = new System.Net.NetworkCredential(                                                                                            "desktopadmmonitor@gmail.com", "EagleEye$");
                smtp.EnableSsl = true;
                MailAddress _from = new MailAddress(Id);
                MailAddress _to = new MailAddress(Id);

                MailMessage mail = new MailMessage(_from, _to);
                mail.Subject = "Alert";
                mail.Body = Body;
                mail.IsBodyHtml = true;
                smtp.Send(mail);
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Email security error !!", "Alert", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
            }
        }
    }
}
