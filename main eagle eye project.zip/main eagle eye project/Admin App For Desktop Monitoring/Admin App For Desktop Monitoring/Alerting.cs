﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Drawing;
using System.IO;

namespace Admin_App_For_Desktop_Monitoring
{
    class Alerting
    {
        private static byte[] ImageToByte(Image img)
        {
            ImageConverter converter = new ImageConverter();
            return (byte[])converter.ConvertTo(img, typeof(byte[]));
        }

        public static bool  Upload(Image Img, ref string Filename )
        {
            bool status = false;
            try
            {

                Filename = string.Format("{0}{1}{2}{3}{4}{5}.jpg", DateTime.Now.Day, DateTime.Now.Month, DateTime.Now.Year, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

                FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://torus-solutions.com/"+ Filename);
                request.Method = WebRequestMethods.Ftp.UploadFile;

                // This example assumes the FTP site uses authenticated login
                request.Credentials = new NetworkCredential("wsafety", "Mx90q^o0");

                // Copy the contents of the file to the request stream.

                byte[] ImageData = ImageToByte(Img);
                request.ContentLength = ImageData.Length; //  inform the size of the file we are uploading

                Stream requestStream = request.GetRequestStream();
                requestStream.Write(ImageData, 0, ImageData.Length);
                requestStream.Close();

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                response.Close();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }
    }
}
