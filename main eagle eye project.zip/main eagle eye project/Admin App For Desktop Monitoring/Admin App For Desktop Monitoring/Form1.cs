﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using RemoteLibrary;

namespace Admin_App_For_Desktop_Monitoring
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (ValidateLoginForm())
            {
                if ( txtUserName.Text =="admin" && txtPassword.Text=="admin")
                {
                    frmMain frmObj = new frmMain();
                    frmObj.Show();
                    this.Hide();
                    TcpChannel _channel = new TcpChannel(7000);
                    ChannelServices.RegisterChannel(_channel);
                    RemotingConfiguration.RegisterWellKnownServiceType(typeof(RemoteClass), "Server", WellKnownObjectMode.SingleCall);
                    RemotingConfiguration.CustomErrorsMode = CustomErrorsModes.Off;
                }
                else
                {
                    MessageBox.Show("User Name/Password is incorrect!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool ValidateLoginForm()
        {
            if (txtUserName.Text.Trim().Length == 0)
            {
                MessageBox.Show("User Name is required!");
                txtUserName.Focus();
                return false;
            }
            if (txtPassword.Text.Trim().Length == 0)
            {
                MessageBox.Show("Password is required!");
                txtPassword.Focus();
                return false;
            }
            return true;
        }
   
    }
}
