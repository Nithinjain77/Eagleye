﻿namespace Admin_App_For_Desktop_Monitoring
{
    partial class ucRemoteTerminal
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucRemoteTerminal));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.killToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.shutDownIcon = new System.Windows.Forms.PictureBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbDrives = new System.Windows.Forms.ComboBox();
            this.MemChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.BtnDiscover = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.flpRemoteFrames = new System.Windows.Forms.FlowLayoutPanel();
            this.btnStart = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnSendMessage = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.BtnRestricted = new System.Windows.Forms.Button();
            this.SrchPicBox = new System.Windows.Forms.PictureBox();
            this.TxtProcessName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lvProcessTable = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblProcessIPAddress = new System.Windows.Forms.Label();
            this.btnGetProcesses = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lblUptime = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblIdleTime = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblSysTime = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PicIdleFinder = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shutDownIcon)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MemChart)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SrchPicBox)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicIdleFinder)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.killToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(100, 28);
            // 
            // killToolStripMenuItem
            // 
            this.killToolStripMenuItem.Name = "killToolStripMenuItem";
            this.killToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.killToolStripMenuItem.Text = "Kill";
            this.killToolStripMenuItem.Click += new System.EventHandler(this.killToolStripMenuItem_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.shutDownIcon);
            this.tabPage6.Location = new System.Drawing.Point(4, 33);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(641, 355);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "1 Click shutdown";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // shutDownIcon
            // 
            this.shutDownIcon.Image = ((System.Drawing.Image)(resources.GetObject("shutDownIcon.Image")));
            this.shutDownIcon.Location = new System.Drawing.Point(178, 52);
            this.shutDownIcon.Name = "shutDownIcon";
            this.shutDownIcon.Size = new System.Drawing.Size(235, 240);
            this.shutDownIcon.TabIndex = 0;
            this.shutDownIcon.TabStop = false;
            this.shutDownIcon.Click += new System.EventHandler(this.shutDownIcon_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.CmbDrives);
            this.tabPage1.Controls.Add(this.MemChart);
            this.tabPage1.Controls.Add(this.BtnDiscover);
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(641, 355);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Storage";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Avail drives";
            // 
            // CmbDrives
            // 
            this.CmbDrives.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbDrives.FormattingEnabled = true;
            this.CmbDrives.Location = new System.Drawing.Point(21, 83);
            this.CmbDrives.Name = "CmbDrives";
            this.CmbDrives.Size = new System.Drawing.Size(164, 32);
            this.CmbDrives.TabIndex = 2;
            this.CmbDrives.SelectedIndexChanged += new System.EventHandler(this.CmbDrives_SelectedIndexChanged);
            // 
            // MemChart
            // 
            chartArea1.Name = "ChartArea1";
            this.MemChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.MemChart.Legends.Add(legend1);
            this.MemChart.Location = new System.Drawing.Point(211, 35);
            this.MemChart.Name = "MemChart";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.MemChart.Series.Add(series1);
            this.MemChart.Size = new System.Drawing.Size(362, 307);
            this.MemChart.TabIndex = 1;
            this.MemChart.Text = "chart1";
            // 
            // BtnDiscover
            // 
            this.BtnDiscover.Location = new System.Drawing.Point(21, 17);
            this.BtnDiscover.Name = "BtnDiscover";
            this.BtnDiscover.Size = new System.Drawing.Size(105, 38);
            this.BtnDiscover.TabIndex = 0;
            this.BtnDiscover.Text = "Discover Info";
            this.BtnDiscover.UseVisualStyleBackColor = true;
            this.BtnDiscover.Click += new System.EventHandler(this.BtnDiscover_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.flpRemoteFrames);
            this.tabPage4.Controls.Add(this.btnStart);
            this.tabPage4.Location = new System.Drawing.Point(4, 33);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(641, 355);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Desktop View";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // flpRemoteFrames
            // 
            this.flpRemoteFrames.AutoScroll = true;
            this.flpRemoteFrames.Location = new System.Drawing.Point(16, 54);
            this.flpRemoteFrames.Name = "flpRemoteFrames";
            this.flpRemoteFrames.Size = new System.Drawing.Size(546, 287);
            this.flpRemoteFrames.TabIndex = 2;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(14, 15);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(108, 28);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start Monitor";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStartMonitor);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnSendMessage);
            this.tabPage3.Location = new System.Drawing.Point(4, 33);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(641, 355);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Send Message";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnSendMessage
            // 
            this.btnSendMessage.Location = new System.Drawing.Point(19, 22);
            this.btnSendMessage.Name = "btnSendMessage";
            this.btnSendMessage.Size = new System.Drawing.Size(550, 57);
            this.btnSendMessage.TabIndex = 0;
            this.btnSendMessage.Text = "Broadcast Message";
            this.btnSendMessage.UseVisualStyleBackColor = true;
            this.btnSendMessage.Click += new System.EventHandler(this.btnSendMessage_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.BtnRestricted);
            this.tabPage2.Controls.Add(this.SrchPicBox);
            this.tabPage2.Controls.Add(this.TxtProcessName);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.lvProcessTable);
            this.tabPage2.Controls.Add(this.lblProcessIPAddress);
            this.tabPage2.Controls.Add(this.btnGetProcesses);
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(641, 355);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Process Monitor";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // BtnRestricted
            // 
            this.BtnRestricted.Location = new System.Drawing.Point(135, 11);
            this.BtnRestricted.Name = "BtnRestricted";
            this.BtnRestricted.Size = new System.Drawing.Size(129, 29);
            this.BtnRestricted.TabIndex = 6;
            this.BtnRestricted.Text = "Restricted list";
            this.BtnRestricted.UseVisualStyleBackColor = true;
            this.BtnRestricted.Click += new System.EventHandler(this.BtnRestricted_Click);
            // 
            // SrchPicBox
            // 
            this.SrchPicBox.Image = ((System.Drawing.Image)(resources.GetObject("SrchPicBox.Image")));
            this.SrchPicBox.Location = new System.Drawing.Point(535, 43);
            this.SrchPicBox.Name = "SrchPicBox";
            this.SrchPicBox.Size = new System.Drawing.Size(35, 40);
            this.SrchPicBox.TabIndex = 5;
            this.SrchPicBox.TabStop = false;
            this.SrchPicBox.Click += new System.EventHandler(this.SrchPicBox_Click);
            // 
            // TxtProcessName
            // 
            this.TxtProcessName.Location = new System.Drawing.Point(343, 43);
            this.TxtProcessName.Name = "TxtProcessName";
            this.TxtProcessName.Size = new System.Drawing.Size(186, 32);
            this.TxtProcessName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(339, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Process name";
            // 
            // lvProcessTable
            // 
            this.lvProcessTable.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvProcessTable.FullRowSelect = true;
            this.lvProcessTable.GridLines = true;
            this.lvProcessTable.Location = new System.Drawing.Point(7, 89);
            this.lvProcessTable.Name = "lvProcessTable";
            this.lvProcessTable.Size = new System.Drawing.Size(575, 256);
            this.lvProcessTable.TabIndex = 2;
            this.lvProcessTable.UseCompatibleStateImageBehavior = false;
            this.lvProcessTable.View = System.Windows.Forms.View.Details;
            this.lvProcessTable.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lvProcessTable_MouseClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Process Id";
            this.columnHeader1.Width = 87;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Process Name";
            this.columnHeader2.Width = 189;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Window Title";
            this.columnHeader3.Width = 260;
            // 
            // lblProcessIPAddress
            // 
            this.lblProcessIPAddress.AutoSize = true;
            this.lblProcessIPAddress.Location = new System.Drawing.Point(6, 52);
            this.lblProcessIPAddress.Name = "lblProcessIPAddress";
            this.lblProcessIPAddress.Size = new System.Drawing.Size(91, 24);
            this.lblProcessIPAddress.TabIndex = 1;
            this.lblProcessIPAddress.Text = "IPAddress";
            // 
            // btnGetProcesses
            // 
            this.btnGetProcesses.Location = new System.Drawing.Point(6, 11);
            this.btnGetProcesses.Name = "btnGetProcesses";
            this.btnGetProcesses.Size = new System.Drawing.Size(123, 29);
            this.btnGetProcesses.TabIndex = 0;
            this.btnGetProcesses.Text = "Get Processes";
            this.btnGetProcesses.UseVisualStyleBackColor = true;
            this.btnGetProcesses.Click += new System.EventHandler(this.btnGetProcesses_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(2, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(649, 392);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.lblUptime);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Controls.Add(this.lblIdleTime);
            this.tabPage5.Controls.Add(this.label3);
            this.tabPage5.Controls.Add(this.lblSysTime);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.PicIdleFinder);
            this.tabPage5.Location = new System.Drawing.Point(4, 33);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(641, 355);
            this.tabPage5.TabIndex = 7;
            this.tabPage5.Text = "Idle finder";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // lblUptime
            // 
            this.lblUptime.AutoSize = true;
            this.lblUptime.Location = new System.Drawing.Point(517, 212);
            this.lblUptime.Name = "lblUptime";
            this.lblUptime.Size = new System.Drawing.Size(0, 24);
            this.lblUptime.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(308, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "Machine up/login time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(329, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Click above icon to choose machine-ip";
            // 
            // lblIdleTime
            // 
            this.lblIdleTime.AutoSize = true;
            this.lblIdleTime.Location = new System.Drawing.Point(517, 134);
            this.lblIdleTime.Name = "lblIdleTime";
            this.lblIdleTime.Size = new System.Drawing.Size(0, 24);
            this.lblIdleTime.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(302, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Idle time(Mins)";
            // 
            // lblSysTime
            // 
            this.lblSysTime.AutoSize = true;
            this.lblSysTime.Location = new System.Drawing.Point(517, 52);
            this.lblSysTime.Name = "lblSysTime";
            this.lblSysTime.Size = new System.Drawing.Size(0, 24);
            this.lblSysTime.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(298, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Idle from ";
            // 
            // PicIdleFinder
            // 
            this.PicIdleFinder.Image = ((System.Drawing.Image)(resources.GetObject("PicIdleFinder.Image")));
            this.PicIdleFinder.Location = new System.Drawing.Point(26, 24);
            this.PicIdleFinder.Name = "PicIdleFinder";
            this.PicIdleFinder.Size = new System.Drawing.Size(245, 235);
            this.PicIdleFinder.TabIndex = 0;
            this.PicIdleFinder.TabStop = false;
            this.PicIdleFinder.Click += new System.EventHandler(this.PicIdleFinder_Click);
            // 
            // ucRemoteTerminal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucRemoteTerminal";
            this.Size = new System.Drawing.Size(659, 405);
            this.Load += new System.EventHandler(this.ucRemoteTerminal_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.shutDownIcon)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MemChart)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SrchPicBox)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicIdleFinder)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem killToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbDrives;
        private System.Windows.Forms.DataVisualization.Charting.Chart MemChart;
        private System.Windows.Forms.Button BtnDiscover;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.FlowLayoutPanel flpRemoteFrames;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnSendMessage;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView lvProcessTable;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label lblProcessIPAddress;
        private System.Windows.Forms.Button btnGetProcesses;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.PictureBox shutDownIcon;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.PictureBox PicIdleFinder;
        private System.Windows.Forms.Label lblIdleTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSysTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtProcessName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox SrchPicBox;
        private System.Windows.Forms.Button BtnRestricted;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblUptime;
        private System.Windows.Forms.Label label6;
    }
}
