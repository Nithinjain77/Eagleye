﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RemoteLibrary;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace Admin_App_For_Desktop_Monitoring
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }


        private void btnRemote_Click(object sender, EventArgs e)
        {
            pnlFrame.Controls.Clear();
            ucRemoteTerminal remoteObj = new ucRemoteTerminal();
            pnlFrame.Controls.Add(remoteObj);
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Application.OpenForms.Count; i++)
                Application.OpenForms[i].Close();

            Application.ExitThread();
        }

    }
}
