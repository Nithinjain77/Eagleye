﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using RemoteLibrary;

namespace Admin_App_For_Desktop_Monitoring
{
    public partial class frmFullScreen : Form
    {
        public frmFullScreen()
        {
            InitializeComponent();
        }

        public static string _selectedAddress = String.Empty;
        Thread _rfbThread = null;
        RemoteClass _remoteObj = null;

        private void frmFullScreen_Load(object sender, EventArgs e)
        {
            _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + _selectedAddress + ":7000/Server");
            _rfbThread = new Thread(new ThreadStart(ReceiveRemoteFrames));
            _rfbThread.Start();
        }

        private void ReceiveRemoteFrames()
        {
            while (_rfbThread.IsAlive)
            {
                try
                {
                    pictureBox1.Image = Image.FromStream(new MemoryStream(_remoteObj.CaptureScreen()));
                }
                catch { }
            }
        }

   

        private void frmFullScreen_FormClosing(object sender, FormClosingEventArgs e)
        {
            _selectedAddress = String.Empty;
            if (_rfbThread != null && _rfbThread.IsAlive)
                _rfbThread.Abort();

            this.DialogResult = DialogResult.OK;
        }

        private void closeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _selectedAddress = String.Empty;
            if (_rfbThread != null && _rfbThread.IsAlive)
                _rfbThread.Abort();

            this.DialogResult = DialogResult.OK;
        }

        private void captureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("It will take few seconds , so please patience until acknowledge", "Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
            string Filename = null;
            bool flag = Alerting.Upload(pictureBox1.Image, ref Filename);
            if (flag)
            {
                RapidMailSender.Send("kumarnithin724@gmail.com", "Image uploaded of IpAddress " + _selectedAddress + " to cloud , you can <a href=http://www.svachallan.com/images/" + Filename + ">Click here </a>");
                MessageBox.Show("Done", "Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to send , due to Internet or connectivity issue !!", "Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
