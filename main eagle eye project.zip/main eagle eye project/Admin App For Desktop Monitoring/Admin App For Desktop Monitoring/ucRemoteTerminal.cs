﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Threading;
using System.IO;
using RemoteLibrary;
using System.Diagnostics;

namespace Admin_App_For_Desktop_Monitoring
{
    public partial class ucRemoteTerminal : UserControl
    {
        public ucRemoteTerminal()
        {
            InitializeComponent();
        }
        Thread _rfbThread = null;
        public static Hashtable _hashObj = new Hashtable();
        public static string ProcessIpAddress;
        ArrayList processlist = new ArrayList();
        private void ucRemoteTerminal_Load(object sender, EventArgs e)
        {
            string[] plist = System.IO.File.ReadAllLines("plist.txt");
            for (int i = 0; i < plist.Length; i++)
            {
                processlist.Add(plist[i].ToLower());
            }
        }

        protected void btnStartMonitor(object sender, EventArgs e)
        {
            if (btnStart.Text == "Start Monitor")
            {
                frmIPSelection _frmObj = new frmIPSelection();
                _frmObj.Tag = "Monitor";
                if (_frmObj.ShowDialog() == DialogResult.OK)
                {
                    CreatePreviewLayout();
                    _rfbThread = new Thread(new ThreadStart(ReceiveRemoteFrames));
                    _rfbThread.Start();

                    btnStart.Text = "Stop Montitor";
                }
            }
            else
            {
                flpRemoteFrames.Controls.Clear();
                if (_rfbThread != null)
                    if (_rfbThread.IsAlive)
                        _rfbThread.Abort();
                btnStart.Text = "Start Monitor";
            }
        }

        private void CreatePreviewLayout()
        {
            TableLayoutPanel _outerTab = new TableLayoutPanel();
            _outerTab.AutoSize = true;

            int _rowCount = 0, _colCount = 0;
            foreach (string _address in _hashObj.Keys)
            {
                TableLayoutPanel _innerTab = new TableLayoutPanel();
                _innerTab.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
                _innerTab.AutoSize = true;

                Label lblIpAddress = new Label();
                lblIpAddress.ForeColor = Color.Red;
                lblIpAddress.AutoSize = true;
                lblIpAddress.Text = _address;
                lblIpAddress.Anchor = AnchorStyles.None;
                _innerTab.Controls.Add(lblIpAddress, 0, 0);

                PictureBox pboxPreview = new PictureBox();
                pboxPreview.Name = _address;
                pboxPreview.Width = 250;
                pboxPreview.Height = 222;
                pboxPreview.BackColor = Color.Black;
                pboxPreview.SizeMode = PictureBoxSizeMode.StretchImage;
                pboxPreview.DoubleClick += new EventHandler(pboxPreview_DoubleClick);
                _innerTab.Controls.Add(pboxPreview, 0, 1);

                _outerTab.Controls.Add(_innerTab, _colCount % 2, _rowCount);
                if (_colCount % 2 == 1)
                    _rowCount++;
                _colCount++;
            }
            flpRemoteFrames.Controls.Add(_outerTab);
        }

        private void ReceiveRemoteFrames()
        {
            while (_rfbThread.IsAlive)
            {
                try
                {
                    foreach (string _address in _hashObj.Keys)
                    {
                        try
                        {
                            RemoteClass _remoteObj = (RemoteClass)_hashObj[_address];
                            PictureBox pboxPreview = (PictureBox)flpRemoteFrames.Controls.Find(_address, true)[0];
                            byte[] imgdata = _remoteObj.CaptureScreen();
                            Random rnd = new Random();
                            string filename = "_desktop" + rnd.Next(9999) + ".jpg";
                            File.WriteAllBytes(filename, imgdata);
                            pboxPreview.Image = Image.FromFile(filename);
                            //pboxPreview.Image = Image.FromStream(new MemoryStream());
                        }
                        catch( Exception e ){
                        
                        }
                    }
                }
                catch { }
            }
        }

        private void pboxPreview_DoubleClick(object sender, EventArgs e)
        {
            _rfbThread.Suspend();
            PictureBox _pboxObj = (PictureBox)sender;
            frmFullScreen._selectedAddress = _pboxObj.Name;

            frmFullScreen _frmObj = new frmFullScreen();
            if (_frmObj.ShowDialog() == DialogResult.OK)
                _rfbThread.Resume();
        }

        private void cmbUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
             
        }
 
        private void btnSendMessage_Click(object sender, EventArgs e)
        {
            frmIPSelection _frmObj = new frmIPSelection();
            _frmObj.Tag = "Message";
            _frmObj.ShowDialog();
        }

        private void btnGetProcesses_Click(object sender, EventArgs e)
        {
            frmIPSelection _frmObj = new frmIPSelection();
            _frmObj.Tag = "Process";
            lvProcessTable.Items.Clear();
            lblProcessIPAddress.Text = "IPAddress : ";
            if (_frmObj.ShowDialog() == DialogResult.OK)
            {
                RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + ProcessIpAddress + ":7000/Server");
                string [] prc = _remoteObj.GetProcesses();
                foreach (string p in prc)
                {
                    string[] cols = p.Split('~');
                    ListViewItem lvItem = new ListViewItem(cols[0]);

                    if (processlist.IndexOf(cols[1].ToLower()) != -1)
                        lvItem.BackColor = Color.Red;

                    lvItem.SubItems.Add(cols[1]);
                    lvItem.SubItems.Add(cols[1]);
                    lvProcessTable.Items.Add(lvItem);

                }
                lblProcessIPAddress.Text = "IPAddress : "+ProcessIpAddress;
            }
             
           /*Process[] prc = Process.GetProcesses();
            foreach (Process p in prc)
            {
                ListViewItem lvItem = new ListViewItem(Convert.ToString(p.Id));
                lvItem.SubItems.Add(p.ProcessName);
                lvItem.SubItems.Add(p.MainWindowTitle);
                lvProcessTable.Items.Add(lvItem);
            } */

        }


        private void lvProcessTable_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                if (lvProcessTable.SelectedItems.Count > 0)
                {
                    contextMenuStrip1.Show(lvProcessTable, new Point(e.X, e.Y));
                }
            }
        }

        private void killToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvProcessTable.SelectedItems.Count > 0)
            {
                int processId = Convert.ToInt32(lvProcessTable.SelectedItems[0].Text);
                RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + ProcessIpAddress + ":7000/Server");
                _remoteObj.KillProcess(processId);
                lvProcessTable.Items.Remove(lvProcessTable.SelectedItems[0]);
            }
        }

        private void chkUser_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void BtnDiscover_Click(object sender, EventArgs e)
        {
             frmIPSelection _frmObj = new frmIPSelection();
             _frmObj.Tag = "Storage";
             ProcessIpAddress = null;
            if (_frmObj.ShowDialog() == DialogResult.OK)
            {
                if (ProcessIpAddress != null)
                {
                    RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + ProcessIpAddress + ":7000/Server");

                    CmbDrives.Items.Clear();
                    string[] items = _remoteObj.GetMemory(); // { "C$7342$83743", "D$8374$342", "E$9343$8734" }; // invoke remote function here
                    CmbDrives.Tag = items;
                    foreach (string item in items)
                    {
                        if (item == null) continue;
                        string[] vals = item.Split('$');
                        CmbDrives.Items.Add(vals[0]);
                    }
                }
            }
        }


        private void chart( int index)
        {
            MemChart.Series[0].Points.Clear();
            string[] DriveInfo = (string[ ]) CmbDrives.Tag;
            string [] vals = DriveInfo[index].Split('$');

            double free_space = double.Parse(vals[2]) / (1024*1024*1024);
            double total_space = double.Parse(vals[1]) / (1024*1024*1024);

            double used = total_space - free_space;
            MemChart.Series["Series1"].Points.AddY(free_space);
            MemChart.Series["Series1"].Points.AddY(used);

            MemChart.Series["Series1"].Points[0].LegendText = "Free :" +  free_space.ToString("f2")   + " Gb";
            MemChart.Series["Series1"].Points[1].LegendText = "Used :" +  used.ToString("f2")  + " Gb";
        }

        private void CmbDrives_SelectedIndexChanged(object sender, EventArgs e)
        {
            if( CmbDrives.SelectedIndex >= 0 )
                    chart(CmbDrives.SelectedIndex);
        }

        private void shutDownIcon_Click(object sender, EventArgs e)
        {
            frmIPSelection _frmObj = new frmIPSelection();
            _frmObj.Tag = "Shutdown";
            _frmObj.ShowDialog();
        }

        private void PicIdleFinder_Click(object sender, EventArgs e)
        {
            frmIPSelection _frmObj = new frmIPSelection();
            _frmObj.Tag = "Idle";
            ProcessIpAddress = null;
            if (_frmObj.ShowDialog() == DialogResult.OK)
            {
                if (ProcessIpAddress != null)
                {
                    RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + ProcessIpAddress + ":7000/Server");
                    long lastInput = _remoteObj.GetIdleTime();
                    double ms = (lastInput / 1000.0) / 60.0;
                    lblIdleTime.Text = ms.ToString("f2");
                    double diff = ms * -1;
                    lblSysTime.Text = DateTime.Now.AddMinutes(diff).ToString();
                    //lblUptime.Text = _remoteObj.UpTime();
                    lblUptime.Text = UpTime();
                }
            }
        }
        public static string UpTime()
        {
            using (var uptime = new PerformanceCounter("System", "System Up Time"))
            {
                uptime.NextValue();       //Call this an extra time before reading its value
                TimeSpan span = TimeSpan.FromSeconds(uptime.NextValue());
                return span.Hours + ":" + span.Minutes + ":" + span.Seconds;
            }
        }

        private void SrchPicBox_Click(object sender, EventArgs e)
        {
            Search(TxtProcessName.Text);
        }

        private void Search (string Search)
        {
            string iSearch = Search.ToLower();
            foreach (ListViewItem item in lvProcessTable.Items)
            {
                if (item.SubItems[1].Text.ToLower().Contains(iSearch))
                {
                    item.BackColor = Color.Yellow;
                    lvProcessTable.TopItem = item;
                    break;
                }
            }
        }

        private void BtnRestricted_Click(object sender, EventArgs e)
        {
            ManageProcess frm = new ManageProcess();
            frm.ShowDialog();
        }
 
   }
}
