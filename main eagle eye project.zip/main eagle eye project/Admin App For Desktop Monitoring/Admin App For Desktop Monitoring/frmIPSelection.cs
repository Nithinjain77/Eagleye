﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using RemoteLibrary;

namespace Admin_App_For_Desktop_Monitoring
{
    public partial class frmIPSelection : Form
    {
        public frmIPSelection()
        {
            InitializeComponent();
            CheckedListBox.CheckForIllegalCrossThreadCalls = false;
        }

        Thread _threadObj = null;
        Socket _socketObj = null;

        private void frmIPSelection_Load(object sender, EventArgs e)
        {
            if (this.Tag.ToString() == "Idle")
            {
                btnConnect.Text = "Connect to find idletime";
                textBox1.Visible = false;
            }
            else if (this.Tag.ToString() == "Shutdown")
            {
                btnConnect.Text = "Connect to Shutdown";
                textBox1.Visible = false;
            }
            else if (this.Tag.ToString() == "Process" || this.Tag.ToString() == "Storage")
            {
                btnConnect.Text = "Get " + this.Tag.ToString();
                textBox1.Visible = false;
            }
            else if (this.Tag.ToString() == "Message")
            {
                textBox1.Visible = true;
                textBox1.Text = "Enter your message here";
                textBox1.SelectionStart = 0;
                textBox1.SelectionLength = textBox1.Text.Length;
                textBox1.Focus();
                btnConnect.Text = "Send Message";
            }
            else
            {
                textBox1.Visible = false;
                btnConnect.Text = "Connect to Selected";
            }
            _threadObj = new Thread(new ThreadStart(run));
            _threadObj.Start();
        }

        private void run()
        {
            while (_threadObj.IsAlive)
            {
                Thread _subThreadObj = new Thread(new ThreadStart(SendBroadCast));
                _subThreadObj.Start();
                _subThreadObj.Join(3000);
                _subThreadObj.Abort();
                _socketObj.Close();

                Thread.Sleep(20000);
            }
        }

        private void SendBroadCast()
        {
            string _myIpAddress = GetMyIpAddress();

            Byte[] _byteArray = System.Text.Encoding.ASCII.GetBytes("Hello");
            _socketObj = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            _socketObj.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);
            EndPoint r_endp = new IPEndPoint(IPAddress.Any, 8000);
            try
            {
                _socketObj.Bind(r_endp);
            }
            catch (Exception err) {   }
            EndPoint s_endp = new IPEndPoint(IPAddress.Broadcast, 8000);
            _socketObj.SendTo(_byteArray, s_endp);

            chkAddress.Items.Clear();
            for (int i = 0; i < Program.ips.Count; i++)
            {
                chkAddress.Items.Add(Program.ips[i]);
            }

            while (_threadObj.IsAlive)
            {
                try
                {
                    if (_threadObj.IsAlive && _socketObj.Available > 0)
                    {
                        _socketObj.ReceiveFrom(_byteArray, ref r_endp);

                        string _senderAddress = r_endp.ToString().Split(':')[0];
                        if (Program.ips.Contains(_senderAddress) == false && _senderAddress != _myIpAddress)
                            Program.ips.Add(_senderAddress);

                        if (_senderAddress != _myIpAddress && !chkAddress.Items.Contains(_senderAddress))
                            chkAddress.Items.Add(_senderAddress);
                    }
                }
                catch { }
            }
        }

        private static string GetMyIpAddress()
        {
            IPAddress[] ips = Dns.GetHostEntry(System.Environment.MachineName).AddressList;
            foreach (IPAddress ip in ips)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                    return ip.ToString();
            }
            return "127.0.0.1";
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (btnSelect.Text == "Select All")
            {
                for (int i = 0; i < chkAddress.Items.Count; i++)
                    chkAddress.SetItemChecked(i, true);
                btnSelect.Text = "De Select All";
            }
            else
            {
                for (int i = 0; i < chkAddress.Items.Count; i++)
                    chkAddress.SetItemChecked(i, false);
                btnSelect.Text = "Select All";

            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (btnConnect.Text == "Get Process" || btnConnect.Text == "Get Storage" || btnConnect.Text == "Connect to find idletime")
            {
                if (chkAddress.CheckedItems.Count == 1)
                {
                    ucRemoteTerminal.ProcessIpAddress = chkAddress.Items[0].ToString();
                }
                else
                {
                    MessageBox.Show("Selected option can support only single IP address", "Select one", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (btnConnect.Text == "Send Message")
            {
                if (textBox1.Text.Trim() == "" || textBox1.Text.Trim() == "Enter your message here")
                {
                    textBox1.Text = "Enter your message here";
                    textBox1.SelectionStart = 0;
                    textBox1.SelectionLength = textBox1.Text.Length;
                    textBox1.Focus();
                    return;
                }

                //Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                //byte[] msg = ASCIIEncoding.ASCII.GetBytes(textBox1.Text);

                foreach (string _address in chkAddress.CheckedItems)
                {
                    RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + _address + ":7000/Server");
                    _remoteObj.SendAlert(textBox1.Text);
                }
                
            }
            else if (btnConnect.Text == "Connect to Shutdown")
            {
                DialogResult res = MessageBox.Show("Are you sure ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (res == DialogResult.Yes)
                {
                    foreach (string _address in chkAddress.CheckedItems)
                    {
                        RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + _address + ":7000/Server");
                        _remoteObj.shutdown();
                    }
                }
            }
            else
            {
                ucRemoteTerminal._hashObj.Clear();
                foreach (string _address in chkAddress.CheckedItems)
                {
                    RemoteClass _remoteObj = (RemoteClass)Activator.GetObject(typeof(RemoteClass), "tcp://" + _address + ":7000/Server");
                    ucRemoteTerminal._hashObj.Add(_address, _remoteObj);
                }
            }
            if (_socketObj != null)
            {
                _socketObj.Close();
            }
            this.DialogResult = DialogResult.OK;
        }

        private void frmIPSelection_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_threadObj != null)
                if (_threadObj.IsAlive)
                    _threadObj.Abort();

            if (_socketObj != null)
            {
                _socketObj.Close();
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" || textBox1.Text.Trim() == "Enter your message here")
            {
                textBox1.Text = "Enter your message here";
                textBox1.SelectionStart = 0;
                textBox1.SelectionLength = textBox1.Text.Length;
                textBox1.Focus();
            }
        }
    }
}
