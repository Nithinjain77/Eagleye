﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Admin_App_For_Desktop_Monitoring
{
    public partial class ManageProcess : Form
    {
        public ManageProcess()
        {
            InitializeComponent();
        }

        private void ManageProcess_Load(object sender, EventArgs e)
        {
            string[] p = File.ReadAllLines("plist.txt");
            for (int i = 0; i < p.Length; i++)
            {
                lstProcess.Items.Add(p[i]);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            lstProcess.Items.Insert(0, TxtProcessName.Text);
            TxtProcessName.Clear();
            TxtProcessName.Focus();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            string data = "";
            for (int i = 0; i < lstProcess.Items.Count; i++)
            {
                data += lstProcess.GetItemText(lstProcess.Items[i]) + "\n";
            }
            data = data.Trim();
            System.IO.File.WriteAllText("plist.txt", data);
            this.Close();
        }
    }
}
