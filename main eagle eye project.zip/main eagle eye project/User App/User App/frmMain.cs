﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.Runtime.Remoting.Channels.Tcp;
using RemoteLibrary;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
namespace User_App
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        Socket _socketObj = null;
        Thread _threadObj = null, thr = null;
        private void frmMain_Load(object sender, EventArgs e)
        {
            _threadObj = new Thread(new ThreadStart(ReceiveBroadCast));
            _threadObj.Start();
            TcpChannel _channel = new TcpChannel(7000);
            ChannelServices.RegisterChannel(_channel);
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(RemoteClass), "Server", WellKnownObjectMode.SingleCall);
            RemotingConfiguration.CustomErrorsMode = CustomErrorsModes.Off;
        }


        private void ReceiveMessages()
        {
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            EndPoint ep = new IPEndPoint(IPAddress.Any, 8001);
            socket.Bind(ep);
            while (thr.IsAlive)
            {
                int avail = socket.Available;
                if (avail > 0)
                {
                    byte[] data = new byte[avail];
                    socket.ReceiveFrom(data, ref ep);
                    DialogWindow window = new DialogWindow(ASCIIEncoding.ASCII.GetString(data));
                    window.ShowDialog();
                    //MessageBox.Show(ASCIIEncoding.ASCII.GetString(data), "Message From " + ep.ToString().Split(':')[0], MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Thread.Sleep(200);
            }
        }


        private void ReceiveBroadCast()
        {
            _socketObj = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            EndPoint r_endp = new IPEndPoint(IPAddress.Any, 8000);
            _socketObj.Bind(r_endp);

            while (_threadObj.IsAlive)
            {
                if (_socketObj.Available > 0)
                {
                    try
                    {
                        Byte[] _byteArray = new Byte[_socketObj.Available];
                        _socketObj.ReceiveFrom(_byteArray, ref r_endp);

                       string _senderAddress = r_endp.ToString().Split(':')[0];
                        EndPoint s_endp = new IPEndPoint(IPAddress.Parse(_senderAddress), 8000);
                        _socketObj.SendTo(_byteArray, s_endp);
                    }
                    catch { }
                }
                Thread.Sleep(50);
            }
        }

      
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            if (_threadObj != null)
                if (_threadObj.IsAlive)
                    _threadObj.Abort();
            if (thr != null)
                if (thr.IsAlive)
                    thr.Abort();
            if (_socketObj != null)
                _socketObj.Close();

            mynotifyicon.Icon = null;
            Application.ExitThread();
        }

        private void PinStartBtn_Click(object sender, EventArgs e)
        {
            if (_threadObj == null )
            {
                _threadObj = new Thread(new ThreadStart(ReceiveBroadCast));
                _threadObj.Start();

               // thr = new Thread(new ThreadStart(ReceiveMessages));
              //  thr.Start();
            }
            this.Hide();
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == this.WindowState)
            {
                mynotifyicon.Visible = true;
                mynotifyicon.ShowBalloonTip(500);
                this.Hide();
                this.ShowInTaskbar = false;
            }

            else if (FormWindowState.Normal == this.WindowState)
            {
                mynotifyicon.Visible = false;
            }
        }

        private void restoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
        }

    }
}
