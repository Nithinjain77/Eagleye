﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace User_App
{
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 
        public static string ServerIPAddress;
        public static string UserId { get; set; }
        public static string UserName { get; set; }
        public static string Password { get; set; }
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain());
        }
    }
}
